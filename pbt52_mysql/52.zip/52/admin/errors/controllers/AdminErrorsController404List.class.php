<?php
/**
 * @copyright 	&copy; 2005-2019 PHPBoost
 * @license 	https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      Loic ROUCHON <horn@phpboost.com>
 * @version   	PHPBoost 5.2 - last update: 2018 10 23
 * @since   	PHPBoost 3.0 - 2009 12 13
 * @contributor Julien BRISWALTER <j1.seth@phpboost.com>
 * @contributor Arnaud GENET <elenwii@phpboost.com>
*/

class AdminErrorsController404List extends AdminController
{
	/**
	 * @var HTMLForm
	 */
	private $form;
	/**
	 * @var FormButtonSubmit
	 */
	private $submit_button;

	private $view;
	private $lang;

	public function execute(HTTPRequestCustom $request)
	{
		$this->init();

		$current_page = $this->build_table();

		return new AdminErrorsDisplayResponse($this->view, $this->lang['404_list'], $current_page);
	}

	private function init()
	{
		$this->lang = LangLoader::get('admin-errors-common');
		$this->view = new StringTemplate('# INCLUDE MSG # # INCLUDE FORM # # INCLUDE table #');
	}

	private function build_table()
	{
		$table_model = new SQLHTMLTableModel(PREFIX . 'errors_404', 'table', array(
			new HTMLTableColumn($this->lang['404_error_requested_url']),
			new HTMLTableColumn($this->lang['404_error_from_url']),
			new HTMLTableColumn($this->lang['404_error_times'], 'times', 'col-small'),
			new HTMLTableColumn(LangLoader::get_message('delete', 'common'), '', 'col-small')
		), new HTMLTableSortingRule('times', HTMLTableSortingRule::DESC));

		$table = new HTMLTable($table_model, 'table-fixed error-list404');

		$table_model->set_caption($this->lang['404_list']);
		$table_model->set_footer_css_class('footer-error-list404');

		$results = array();
		$result = $table_model->get_sql_results();
		foreach ($result as $row)
		{
			$delete_link = new LinkHTMLElement(AdminErrorsUrlBuilder::delete_404_error($row['id']), '', array('title' => LangLoader::get_message('delete', 'common'), 'data-confirmation' => 'delete-element'), 'fa fa-delete');

			$results[] = new HTMLTableRow(array(
				new HTMLTableRowCell(new LinkHTMLElement($row['requested_url'], $row['requested_url'], array('title' => $this->lang['404_error_requested_url']))),
				new HTMLTableRowCell(new LinkHTMLElement($row['from_url'], $row['from_url'], array('title' => $this->lang['404_error_from_url']))),
				new HTMLTableRowCell($row['times']),
				new HTMLTableRowCell($delete_link->display())
			));
		}
		$table->set_rows($table_model->get_number_of_matching_rows(), $results);

		if ($table_model->get_number_of_matching_rows())
		{
			$this->build_form();

			$this->view->put('FORM', $this->form->display());

			$this->view->put('table', $table->display());
		}
		else
			$this->view->put('MSG', MessageHelper::display(LangLoader::get_message('no_item_now', 'common'), MessageHelper::SUCCESS, 0, true));

		return $table->get_page_number();
	}

	private function build_form()
	{
		$form = new HTMLForm(__CLASS__, AdminErrorsUrlBuilder::clear_404_errors()->rel(), false);

		$fieldset = new FormFieldsetHTML('clear_errors', $this->lang['clear_list']);
		$form->add_fieldset($fieldset);

		$this->submit_button = new FormButtonSubmit($this->lang['clear_list'], 'clear', '', 'submit', $this->lang['logged_errors_clear_confirmation']);
		$form->add_button($this->submit_button);

		$this->form = $form;
	}
}
?>
