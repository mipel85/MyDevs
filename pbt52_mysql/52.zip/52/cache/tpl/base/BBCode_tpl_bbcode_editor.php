<?php $_result='';if ($_data->is_true($_data->get('C_EDITOR_NOT_ALREADY_INCLUDED'))){$_result.='
<script>
<!--
function XMLHttpRequest_preview(field)
{
	if( XMLHttpRequest_preview.arguments.length == 0 )
		field = ' . $_functions->escapejs($_data->get('FIELD')) . ';

	var contents = jQuery(\'#\' + field).val();
	var preview_field = \'xmlhttprequest-preview\' + field;

	if( contents != "" )
	{
		jQuery("#" + preview_field).slideDown(500);

		jQuery(\'#loading-preview-\' + field).show();

		jQuery.ajax({
			url: PATH_TO_ROOT + "/kernel/framework/ajax/content_xmlhttprequest.php",
			type: "post",
			data: {
				token: \'' . $_data->get('TOKEN') . '\',
				path_to_root: \'' . $_data->get('PHP_PATH_TO_ROOT') . '\',
				editor: \'BBCode\',
				page_path: \'' . $_data->get('PAGE_PATH') . '\',
				contents: contents,
				ftags: \'' . $_data->get('FORBIDDEN_TAGS') . '\'
			},
			success: function(returnData){
				jQuery(\'#\' + preview_field).html(returnData);
				jQuery(\'#loading-preview-\' + field).hide();
			}
		});
	}
	else
		alert("' . LangLoader::get_message('require_text', 'main') . '");
}
-->
</script>
<script src="' . $_data->get('PATH_TO_ROOT') . '/BBCode/templates/js/bbcode.js"></script>
';}$_result.='

<div id="loading-preview-' . $_data->get('FIELD') . '" class="loading-preview-container" style="display: none;">
	<div class="loading-preview">
		<i class="fa fa-spinner fa-2x fa-spin"></i>
	</div>
</div>

<div id="xmlhttprequest-preview' . $_data->get('FIELD') . '" class="xmlhttprequest-preview" style="display: none;"></div>

<div id="bbcode-expanded" class="bbcode expand bkgd-color-op10 bdr-color-op20">
	<div class="bbcode-containers">
		<ul id="bbcode-container-smileys" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SMILEYS') . 'bb_display_block(\'1\', \'' . $_data->get('FIELD') . '\');return false;" onmouseover="' . $_data->get('DISABLED_SMILEYS') . 'bb_hide_block(\'1\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'1\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_SMILEYS') . '" aria-label="' . $_functions->i18n('bb_smileys') . '">
					<i class="fa fa-fw bbcode-icon-smileys" aria-hidden="true" title="' . $_functions->i18n('bb_smileys') . '"></i>
				</a>
				<div id="bb-block1' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-smileys" onmouseover="bb_hide_block(\'1\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'1\', \'' . $_data->get('FIELD') . '\', 0);">
						';foreach($_data->get_block('smileys') as $_tmp_smileys){$_result.='
							<li>
								<a href="" onclick="insertbbcode(\'' . $_data->get_from_list('CODE', $_tmp_smileys) . '\', \'smile\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'1\', \'' . $_data->get('FIELD') . '\', 0);return false;" class="bbcode-hover" aria-label="' . $_data->get_from_list('CODE', $_tmp_smileys) . '">
									<img src="' . $_data->get_from_list('URL', $_tmp_smileys) . '" alt="' . $_data->get_from_list('CODE', $_tmp_smileys) . '" aria-hidden="true" title="' . $_data->get_from_list('CODE', $_tmp_smileys) . '" class="smiley" />
								</a>
							</li>
						';}$_result.='
					</ul>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-fonts" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_B') . 'insertbbcode(\'[b]\', \'[/b]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_bold') . '">
					<i class="fa fa-fw bbcode-icon-bold' . $_data->get('AUTH_B') . '" aria-hidden="true" title="' . $_functions->i18n('bb_bold') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_I') . 'insertbbcode(\'[i]\', \'[/i]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_italic') . '">
					<i class="fa fa-fw bbcode-icon-italic' . $_data->get('AUTH_I') . '" aria-hidden="true" title="' . $_functions->i18n('bb_italic') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_U') . 'insertbbcode(\'[u]\', \'[/u]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_underline') . '">
					<i class="fa fa-fw bbcode-icon-underline' . $_data->get('AUTH_U') . '" aria-hidden="true" title="' . $_functions->i18n('bb_underline') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_S') . 'insertbbcode(\'[s]\', \'[/s]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_strike') . '">
					<i class="fa fa-fw bbcode-icon-strike' . $_data->get('AUTH_S') . '" aria-hidden="true" title="' . $_functions->i18n('bb_strike') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_COLOR') . 'bbcode_color(\'5\', \'' . $_data->get('FIELD') . '\', \'color\');bb_display_block(\'5\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_COLOR') . 'bb_hide_block(\'5\', \'' . $_data->get('FIELD') . '\', 0);" aria-label="' . $_functions->i18n('bb_color') . '" class="' . $_data->get('AUTH_COLOR') . '">
					<i class="fa fa-fw bbcode-icon-color" aria-hidden="true" title="' . $_functions->i18n('bb_color') . '"></i>
				</a>
				<div id="bb-block5' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color color-picker" style="display: none;">
					<div id="bb-color' . $_data->get('FIELD') . '" class="bbcode-block" onmouseover="bb_hide_block(\'5\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'5\', \'' . $_data->get('FIELD') . '\', 0);">
					</div>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'bb_display_block(\'6\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_SIZE') . 'bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_SIZE') . '" aria-label="' . $_functions->i18n('bb_size') . '">
					<i class="fa fa-fw bbcode-icon-size" aria-hidden="true" title="' . $_functions->i18n('bb_size') . '"></i>
				</a>
				<div id="bb-block6' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-size" onmouseover="bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=5]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 05"> 05 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=10]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 10"> 10 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=15]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 15"> 15 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=20]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 20"> 20 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=25]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 25"> 25 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=30]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 30"> 30 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=35]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 35"> 35 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=40]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 40"> 40 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_SIZE') . 'insertbbcode(\'[size=45]\', \'[/size]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'6\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_size', 'editor-common') . ' 45"> 45 </a></li>
					</ul>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_FONT') . 'bb_display_block(\'10\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_FONT') . 'bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_FONT') . '" aria-label="' . $_functions->i18n('bb_font') . '">
					<i class="fa fa-fw bbcode-icon-font" aria-hidden="true" title="' . $_functions->i18n('bb_font') . '"></i>
				</a>
				<div id="bb-block10' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-fonts" onmouseover="bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=andale mono]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Andale Mono"> <span style="font-family: andale mono;">Andale Mono</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=arial]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Arial"> <span style="font-family: arial;">Arial</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=arial black]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Arial Black"> <span style="font-family: arial black;">Arial Black</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=book antiqua]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Book Antiqua"> <span style="font-family: book antiqua;">Book Antiqua</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=comic sans ms]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Comic Sans MS"> <span style="font-family: comic sans ms;">Comic Sans MS</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=courier new]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Courier New"> <span style="font-family: courier new;">Courier New</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=georgia]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Georgia"> <span style="font-family: georgia;">Georgia</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=helvetica]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Helvetica"> <span style="font-family: helvetica;">Helvetica</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=impact]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Impact"> <span style="font-family: impact;">Impact</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=symbol]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Symbol"> <span style="font-family: symbol;">Symbol</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=tahoma]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Tahoma"> <span style="font-family: tahoma;">Tahoma</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=terminal]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Terminal"> <span style="font-family: terminal;">Terminal</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=times new roman]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Times New Roman"> <span style="font-family: times new roman;">Times New Roman</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=trebuchet ms]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Trebuchet MS"> <span style="font-family: trebuchet ms;">Trebuchet MS</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=verdana]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Verdana"> <span style="font-family: verdana;">Verdana</span> </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=webdings]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Webdings"> Webdings </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FONT') . 'insertbbcode(\'[font=wingdings]\', \'[/font]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'10\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_font', 'editor-common') . ' Wingdings"> Wingdings </a></li>
					</ul>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-titles" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'bb_display_block(\'2\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_TITLE') . 'bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_TITLE') . '" aria-label="' . $_functions->i18n('bb_title') . '">
					<i class="fa fa-fw bbcode-icon-title" aria-hidden="true" title="' . $_functions->i18n('bb_title') . '"></i>
				</a>
				<div id="bb-block2' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-title" onmouseover="bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'insertbbcode(\'[title=1]\', \'[/title]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_title', 'editor-common') . ' 1"> ' . LangLoader::get_message('format_title', 'editor-common') . ' 1 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'insertbbcode(\'[title=2]\', \'[/title]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_title', 'editor-common') . ' 2"> ' . LangLoader::get_message('format_title', 'editor-common') . ' 2 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'insertbbcode(\'[title=3]\', \'[/title]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_title', 'editor-common') . ' 3"> ' . LangLoader::get_message('format_title', 'editor-common') . ' 3 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'insertbbcode(\'[title=4]\', \'[/title]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_title', 'editor-common') . ' 4"> ' . LangLoader::get_message('format_title', 'editor-common') . ' 4 </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_TITLE') . 'insertbbcode(\'[title=5]\', \'[/title]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'2\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('format_title', 'editor-common') . ' 5"> ' . LangLoader::get_message('format_title', 'editor-common') . ' 5 </a></li>
					</ul>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_LIST') . 'bb_display_block(\'9\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_LIST') . 'bb_hide_block(\'9\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_LIST') . '" aria-label="' . $_functions->i18n('bb_list') . '">
					<i class="fa fa-fw bbcode-icon-list" aria-hidden="true" title="' . $_functions->i18n('bb_list') . '"></i>
				</a>
				<div id="bb-block9' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<div class="bbcode-block block-submenu-color bbcode-block-ul" onmouseover="bb_hide_block(\'9\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'9\', \'' . $_data->get('FIELD') . '\', 0);">
						<div class="form-element">
							<label class="smaller" for="bb_list' . $_data->get('FIELD') . '">' . $_functions->i18n('lines') . '</label>
							<div class="form-field">
								<input id="bb_list' . $_data->get('FIELD') . '" class="field-smaller" size="3" type="text" name="bb_list' . $_data->get('FIELD') . '" maxlength="3" value="3">
							</div>
						</div>
						<div class="form-element">
							<label class="smaller" for="bb_ordered_list' . $_data->get('FIELD') . '">' . $_functions->i18n('ordered_list') . '</label>
							<div class="form-field">
								<input id="bb_ordered_list' . $_data->get('FIELD') . '" type="checkbox" name="bb_ordered_list' . $_data->get('FIELD') . '" >
							</div>
						</div>
						<div class="bbcode-form-element-text">
							<a class="small" href="" onclick="' . $_data->get('DISABLED_LIST') . 'bbcode_list(\'' . $_data->get('FIELD') . '\');bb_hide_block(\'9\', \'' . $_data->get('FIELD') . '\', 0);return false;">
								<i class="fa fa-fw bbcode-icon-list valign-middle" title="' . $_functions->i18n('bb_list') . '"></i> ' . $_functions->i18n('insert_list') . '
							</a>
						</div>
					</div>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-blocks" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'bb_display_block(\'3\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_BLOCK') . 'bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_BLOCK') . '" aria-label="' . $_functions->i18n('bb_container') . '">
					<i class="fa fa-fw bbcode-icon-subtitle" aria-hidden="true" title="' . $_functions->i18n('bb_container') . '"></i>
				</a>
				<div id="bb-block3' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-block" onmouseover="bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'insertbbcode(\'[p]\', \'[/p]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_container') . ' ' . $_functions->i18n('bb_paragraph_title') . '"> ' . $_functions->i18n('bb_paragraph') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'insertbbcode(\'[container]\', \'[/container]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_container_title') . '"> ' . $_functions->i18n('bb_container') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'insertbbcode(\'[block]\', \'[/block]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'3\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_container') . ' ' . $_functions->i18n('bb_block_title') . '"> ' . $_functions->i18n('bb_block') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'bbcode_fieldset(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_fieldset_prompt')) . ');return false;" title="' . $_functions->i18n('bb_container') . ' ' . $_functions->i18n('bb_fieldset_title') . '"> ' . $_functions->i18n('bb_fieldset') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_BLOCK') . 'bbcode_abbr(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_abbr_prompt')) . ');return false;" title="' . $_functions->i18n('bb_container') . ' ' . $_functions->i18n('bb_abbr_title') . '"> ' . $_functions->i18n('bb_abbr') . ' </a></li>
					</ul>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_QUOTE') . 'bbcode_quote(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_quote_prompt')) . ');return false;" aria-label="' . $_functions->i18n('bb_quote') . '">
					<i class="fa fa-fw bbcode-icon-quote' . $_data->get('AUTH_QUOTE') . '" aria-hidden="true" title="' . $_functions->i18n('bb_quote') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_HIDE') . 'bb_display_block(\'11\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_HIDE') . 'bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_HIDE') . '" aria-label="' . $_functions->i18n('bb_hide') . '">
					<i class="fa fa-fw bbcode-icon-hide" aria-hidden="true" title="' . $_functions->i18n('bb_hide') . '"></i>
				</a>
				<div class="bbcode-block-container arrow-submenu-color" style="display: none;" id="bb-block11' . $_data->get('FIELD') . '">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-hide" onmouseover="bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_HIDE') . 'insertbbcode(\'[hide]\', \'[/hide]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_hide_all') . ' "> ' . $_functions->i18n('bb_hide') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_HIDE') . 'insertbbcode(\'[member]\', \'[/member]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_hide_view_member') . '"> ' . $_functions->i18n('bb_member') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_HIDE') . 'insertbbcode(\'[moderator]\', \'[/moderator]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'11\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_functions->i18n('bb_hide_view_moderator') . '  "> ' . $_functions->i18n('bb_moderator') . ' </a></li>
					</ul>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'bb_display_block(\'4\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_STYLE') . 'bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_STYLE') . '" aria-label="' . $_functions->i18n('bb_style') . '">
					<i class="fa fa-fw bbcode-icon-style" aria-hidden="true" title="' . $_functions->i18n('bb_style') . '"></i>
				</a>
				<div class="bbcode-block-container arrow-submenu-color" style="display: none;" id="bb-block4' . $_data->get('FIELD') . '">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-message" onmouseover="bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'insertbbcode(\'[style=success]\', \'[/style]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('style', 'main') . ' ' . LangLoader::get_message('success', 'main') . '"> ' . LangLoader::get_message('success', 'main') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'insertbbcode(\'[style=question]\', \'[/style]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('style', 'main') . ' ' . LangLoader::get_message('question', 'main') . '"> ' . LangLoader::get_message('question', 'main') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'insertbbcode(\'[style=notice]\', \'[/style]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('style', 'main') . ' ' . LangLoader::get_message('notice', 'main') . '"> ' . LangLoader::get_message('notice', 'main') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'insertbbcode(\'[style=warning]\', \'[/style]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('style', 'main') . ' ' . LangLoader::get_message('warning', 'main') . '"> ' . LangLoader::get_message('warning', 'main') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_STYLE') . 'insertbbcode(\'[style=error]\', \'[/style]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'4\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . LangLoader::get_message('style', 'main') . ' ' . LangLoader::get_message('error', 'main') . '"> ' . LangLoader::get_message('error', 'main') . ' </a></li>
					</ul>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-links" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_URL') . 'bbcode_url(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_url_prompt')) . ');return false;" aria-label="' . $_functions->i18n('bb_link') . '">
					<i class="fa fa-fw bbcode-icon-url' . $_data->get('AUTH_URL') . '" aria-hidden="true" title="' . $_functions->i18n('bb_link') . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-pictures" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_IMG') . 'insertbbcode(\'[img]\', \'[/img]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_picture') . '">
					<i class="fa fa-fw bbcode-icon-image' . $_data->get('AUTH_IMG') . '" aria-hidden="true" title="' . $_functions->i18n('bb_picture') . '"></i>
				</a>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_LIGHTBOX') . 'bbcode_lightbox(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_url_prompt')) . ');return false;" aria-label="' . $_functions->i18n('bb_lightbox') . '">
					<i class="fa fa-fw bbcode-icon-lightbox' . $_data->get('AUTH_LIGHTBOX') . '" aria-hidden="true" title="' . $_functions->i18n('bb_lightbox') . '"></i>
				</a>
			</li>
		</ul>

		';if ($_data->is_true($_data->get('C_UPLOAD_MANAGEMENT'))){$_result.='
		<ul id="bbcode-container-upload" class="bbcode-container dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a aria-label="' . $_functions->i18n('bb_upload') . '" href="#" onclick="window.open(\'' . $_data->get('PATH_TO_ROOT') . '/user/upload.php?popup=1&amp;fd=' . $_data->get('FIELD') . '&amp;edt=BBCode\', \'\', \'height=550,width=720,resizable=yes,scrollbars=yes\');return false;">
					<i class="fa fa-fw bbcode-icon-upload" aria-hidden="true" title="' . $_functions->i18n('bb_upload') . '"></i>
				</a>
			</li>
		</ul>
		';}$_result.='

		<span class="bbcode-backspace"></span>

		<ul id="bbcode-container-fa" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_FA') . 'bb_display_block(\'12\', \'' . $_data->get('FIELD') . '\');return false;" onmouseover="' . $_data->get('DISABLED_FA') . 'bb_hide_block(\'12\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'12\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_FA') . '" aria-label="' . $_functions->i18n('bb_fa') . '">
					<i class="fab fa-fw bbcode-icon-fa" aria-hidden="true" title="' . $_functions->i18n('bb_fa') . '"></i>
				</a>
				<div id="bb-block12' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<ul class="bbcode-block block-submenu-color bbcode-block-fa" onmouseover="bb_hide_block(\'12\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'12\', \'' . $_data->get('FIELD') . '\', 0);">
						';foreach($_data->get_block('code_fa') as $_tmp_code_fa){$_result.='
						<li>
							<a href="" onclick="' . $_data->get('DISABLED_FA') . 'insertbbcode(\'[fa';if ($_data->is_true($_data->get_from_list('C_CUSTOM_PREFIX', $_tmp_code_fa))){$_result.='=' . $_data->get_from_list('PREFIX', $_tmp_code_fa) . '';}$_result.=']' . $_data->get_from_list('CODE', $_tmp_code_fa) . '[/fa]\', \'\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'12\', \'' . $_data->get('FIELD') . '\', 0);return false;" class="bbcode-hover" aria-label="' . $_data->get_from_list('CODE', $_tmp_code_fa) . '">
								<i class="' . $_data->get_from_list('PREFIX', $_tmp_code_fa) . ' fa-' . $_data->get_from_list('CODE', $_tmp_code_fa) . '" aria-hidden="true" title="' . $_data->get_from_list('CODE', $_tmp_code_fa) . '"></i>
							</a>
						</li>
						';}$_result.='
					</ul>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-positions" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_ALIGN') . 'bb_display_block(\'13\', \'' . $_data->get('FIELD') . '\');return false;" onmouseover="' . $_data->get('DISABLED_ALIGN') . 'bb_hide_block(\'13\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'13\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_ALIGN') . '" aria-label="' . $_functions->i18n('bb_align') . '">
					<i class="fa fa-fw bbcode-icon-left" aria-hidden="true" title="' . $_functions->i18n('bb_align') . '"></i>
				</a>
				<div class="bbcode-block-container arrow-submenu-color" style="display: none;" id="bb-block13' . $_data->get('FIELD') . '">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-aligns" onmouseover="bb_hide_block(\'13\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'13\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_ALIGN') . 'insertbbcode(\'[align=left]\', \'[/align]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_left_title') . '"> ' . $_functions->i18n('bb_left') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_ALIGN') . 'insertbbcode(\'[align=center]\', \'[/align]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_center_title') . '"> ' . $_functions->i18n('bb_center') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_ALIGN') . 'insertbbcode(\'[align=right]\', \'[/align]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_left_title') . '"> ' . $_functions->i18n('bb_right') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_ALIGN') . 'insertbbcode(\'[align=justify]\', \'[/align]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_justify_title') . '"> ' . $_functions->i18n('bb_justify') . ' </a></li>
					</ul>
				</div>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_POSITIONS') . 'bb_display_block(\'14\', \'' . $_data->get('FIELD') . '\');return false;" onmouseover="' . $_data->get('DISABLED_POSITIONS') . 'bb_hide_block(\'14\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'14\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_POSITIONS') . '" aria-label="' . $_functions->i18n('bb_positions') . '">
					<i class="fa fa-fw bbcode-icon-indent" aria-hidden="true" title="' . $_functions->i18n('bb_positions') . '"></i>
				</a>
				<div class="bbcode-block-container arrow-submenu-color" style="display: none;" id="bb-block14' . $_data->get('FIELD') . '">
					<ul class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-positions" onmouseover="bb_hide_block(\'14\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'14\', \'' . $_data->get('FIELD') . '\', 0);">
						<li><a href="" onclick="' . $_data->get('DISABLED_FLOAT') . 'insertbbcode(\'[float=left]\', \'[/float]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_float_left_title') . '" class="' . $_data->get('AUTH_ALIGN') . '"> ' . $_functions->i18n('bb_float_left') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_FLOAT') . 'insertbbcode(\'[float=right]\', \'[/float]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_float_right_title') . '" class="' . $_data->get('AUTH_ALIGN') . '"> ' . $_functions->i18n('bb_float_right') . ' </a></li>
						<li><a href="" onclick="' . $_data->get('DISABLED_INDENT') . 'insertbbcode(\'[indent]\', \'[/indent]\', \'' . $_data->get('FIELD') . '\');return false;" title="' . $_functions->i18n('bb_indent_title') . '" class="' . $_data->get('AUTH_INDENT') . '"> ' . $_functions->i18n('bb_indent') . ' </a></li>
					</ul>
				</div>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_TABLE') . 'bb_display_block(\'7\', \'' . $_data->get('FIELD') . '\');return false;" onmouseover="' . $_data->get('DISABLED_TABLE') . 'bb_hide_block(\'7\', \'' . $_data->get('FIELD') . '\', 1);" class="bbcode-hover' . $_data->get('AUTH_TABLE') . '" aria-label="' . $_functions->i18n('bb_table') . '">
					<i class="fa fa-fw bbcode-icon-table" aria-hidden="true" title="' . $_functions->i18n('bb_table') . '"></i>
				</a>
				<div id="bb-block7' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<div id="bbtable' . $_data->get('FIELD') . '" class="bbcode-block block-submenu-color bbcode-block-table" onmouseover="bb_hide_block(\'7\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'7\', \'' . $_data->get('FIELD') . '\', 0);">
						<div class="form-element">
							<label class="smaller" for="bb-lines' . $_data->get('FIELD') . '">' . $_functions->i18n('lines') . '</label>
							<div class="form-field">
								<input type="text" maxlength="2" name="bb-lines' . $_data->get('FIELD') . '" id="bb-lines' . $_data->get('FIELD') . '" value="2" class="field-smaller">
							</div>
						</div>
						<div class="form-element">
							<label class="smaller" for="bb-cols' . $_data->get('FIELD') . '">' . $_functions->i18n('cols') . '</label>
							<div class="form-field">
								<input type="text" maxlength="2" name="bb-cols' . $_data->get('FIELD') . '" id="bb-cols' . $_data->get('FIELD') . '" value="2" class="field-smaller">
							</div>
						</div>
						<div class="form-element">
							<label class="smaller" for="bb-head' . $_data->get('FIELD') . '">' . $_functions->i18n('head_add') . '</label>
							<div class="form-field">
								<input type="checkbox" name="bb-head' . $_data->get('FIELD') . '" id="bb-head' . $_data->get('FIELD') . '" class="field-smaller">
							</div>
						</div>
						<div class="bbcode-form-element-text">
							<a class="small" href="" onclick="' . $_data->get('DISABLED_TABLE') . 'bbcode_table(\'' . $_data->get('FIELD') . '\', \'' . $_functions->i18n('head_table') . '\');bb_hide_block(\'7\', \'' . $_data->get('FIELD') . '\', 0);return false;">
								<i class="fa fa-fw bbcode-icon-table" title="' . $_functions->i18n('bb_table') . '"></i> ' . $_functions->i18n('insert_table') . '
							</a>
						</div>
					</div>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-exp" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SUP') . 'insertbbcode(\'[sup]\', \'[/sup]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_sup') . '">
					<i class="fa fa-fw bbcode-icon-sup' . $_data->get('AUTH_SUP') . '" aria-hidden="true" title="' . $_functions->i18n('bb_sup') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SUB') . 'insertbbcode(\'[sub]\', \'[/sub]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_sub') . '">
					<i class="fa fa-fw bbcode-icon-sub' . $_data->get('AUTH_SUB') . '" aria-hidden="true" title="' . $_functions->i18n('bb_sub') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_BGCOLOR') . 'bbcode_color(\'15\', \'' . $_data->get('FIELD') . '\', \'bgcolor\');bb_display_block(\'15\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_BGCOLOR') . 'bb_hide_block(\'15\', \'' . $_data->get('FIELD') . '\', 0);" aria-label="' . $_functions->i18n('bb_bgcolor') . '" class="' . $_data->get('AUTH_BGCOLOR') . '">
					<i class="fa fa-fw bbcode-icon-bgcolor" aria-hidden="true" title="' . $_functions->i18n('bb_bgcolor') . '"></i>
				</a>
				<div id="bb-block15' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color color-picker" style="display: none;">
					<div id="bb-bgcolor' . $_data->get('FIELD') . '" class="bbcode-block" onmouseover="bb_hide_block(\'15\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'5\', \'' . $_data->get('FIELD') . '\', 0);">
					</div>
				</div>
			</li>
		</ul>

		<ul id="bbcode-container-anchor" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_ANCHOR') . 'bbcode_anchor(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_anchor_prompt')) . ');return false;" aria-label="' . $_functions->i18n('bb_anchor') . '">
					<i class="fa fa-fw bbcode-icon-anchor' . $_data->get('AUTH_ANCHOR') . '" aria-hidden="true" title="' . $_functions->i18n('bb_anchor') . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-movies" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SWF') . 'insertbbcode(\'[swf=425,344]\', \'[/swf]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_swf') . '">
					<i class="fa fa-fw bbcode-icon-flash' . $_data->get('AUTH_SWF') . '" aria-hidden="true" title="' . $_functions->i18n('bb_swf') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_MOVIE') . 'insertbbcode(\'[movie=100,100]\', \'[/movie]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_movie') . '">
					<i class="fa fa-fw bbcode-icon-movie' . $_data->get('AUTH_MOVIE') . '" aria-hidden="true" title="' . $_functions->i18n('bb_movie') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_YOUTUBE') . 'insertbbcode(\'[youtube]\', \'[/youtube]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_youtube') . '">
					<i class="fab fa-fw bbcode-icon-youtube' . $_data->get('AUTH_YOUTUBE') . '" aria-hidden="true" title="' . $_functions->i18n('bb_youtube') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_SOUND') . 'insertbbcode(\'[sound]\', \'[/sound]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_sound') . '">
					<i class="fa fa-fw bbcode-icon-sound' . $_data->get('AUTH_SOUND') . '" aria-hidden="true" title="' . $_functions->i18n('bb_sound') . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-code" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_CODE') . 'bb_display_block(\'8\', \'' . $_data->get('FIELD') . '\');return false;" onmouseout="' . $_data->get('DISABLED_CODE') . 'bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);" class="bbcode-hover' . $_data->get('AUTH_CODE') . '" aria-label="' . $_functions->i18n('bb_code') . '">
					<i class="fa fa-fw bbcode-icon-code" aria-hidden="true" title="' . $_functions->i18n('bb_code') . '"></i>
				</a>
				<div id="bb-block8' . $_data->get('FIELD') . '" class="bbcode-block-container arrow-submenu-color" style="display: none;">
					<div class="bbcode-block block-submenu-color bbcode-block-list bkgd-color-op20-hover bbcode-block-code" onmouseover="bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 1);" onmouseout="bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);">
						<ul>
							<li class="bbcode-code-title bkgd-color-op40"><span>' . $_functions->i18n('bb_text') . '</span></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=text]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' text">Text</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=sql]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' sql">SqL</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=xml]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' xml">Xml</a></li>

							<li class="bbcode-code-title bkgd-color-op40"><span>' . $_functions->i18n('phpboost_languages') . '</span></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=bbcode]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' bbcode">BBCode</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=tpl]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' template">Template</a></li>

							<li class="bbcode-code-title bkgd-color-op40"><span>' . $_functions->i18n('bb_script') . '</span></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=php]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' php">PHP</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=asp]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' asp">Asp</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=python]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' python">Python</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=pearl]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' text">Pearl</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=ruby]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' ruby">Ruby</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=bash]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' bash">Bash</a></li>

							<li class="bbcode-code-title bkgd-color-op40"><span>' . $_functions->i18n('bb_web') . '</span></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=html]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' html">Html</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=css]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' css">Css</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=javascript]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' javascript">Javascript</a></li>

							<li class="bbcode-code-title bkgd-color-op40"><span>' . $_functions->i18n('bb_prog') . '</span></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=c]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' c">C</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=cpp]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' c++">C++</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=c#]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' c#">C#</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=d]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' d">D</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=go]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' go">Go</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=java]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' java">Java</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=pascal]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' pascal">Pascal</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=delphi]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' delphi">Delphi</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=fortran]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' fortran">Fortran</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=vb]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' vb">Vb</a></li>
							<li><a href="" onclick="' . $_data->get('DISABLED_CODE') . 'insertbbcode(\'[code=asm]\', \'[/code]\', \'' . $_data->get('FIELD') . '\');bb_hide_block(\'8\', \'' . $_data->get('FIELD') . '\', 0);return false;" title="' . $_data->get('L_CODE') . ' asm">Asm</a></li>
						</ul>
					</div>
				</div>
			</li>

			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_MATH') . 'insertbbcode(\'[math]\', \'[/math]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_math') . '">
					<i class="fab fa-fw bbcode-icon-math' . $_data->get('AUTH_MATH') . '" aria-hidden="true" title="' . $_functions->i18n('bb_math') . '"></i>
				</a>
			</li>
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_HTML') . 'insertbbcode(\'[html]\', \'[/html]\', \'' . $_data->get('FIELD') . '\');return false;" aria-label="' . $_functions->i18n('bb_html') . '">
					<i class="fab fa-fw bbcode-icon-html' . $_data->get('AUTH_HTML') . '" aria-hidden="true" title="' . $_functions->i18n('bb_html') . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-mail" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_MAIL') . 'bbcode_mail(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_mail_prompt')) . ');return false;" aria-label="' . $_functions->i18n('bb_mail') . '">
					<i class="fa fa-fw bbcode-icon-mail' . $_data->get('AUTH_MAIL') . '" aria-hidden="true" title="' . $_functions->i18n('bb_mail') . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-feed" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="" onclick="' . $_data->get('DISABLED_FEED') . 'bbcode_feed(\'' . $_data->get('FIELD') . '\', ' . $_functions->escapejs($_functions->i18n('bb_feed_prompt')) . ');return false;" aria-label="' . $_functions->escape($_functions->i18n('bb_feed')) . '">
					<i class="fa fa-fw bbcode-icon-feed' . $_data->get('AUTH_FEED') . '" aria-hidden="true" title="' . $_functions->escape($_functions->i18n('bb_feed')) . '"></i>
				</a>
			</li>
		</ul>

		<ul id="bbcode-container-help" class="bbcode-container bbcode-container-more dlt-color-op20-after">
			<li class="bbcode-elements bkgd-color-op20-hover">
				<a href="https://www.phpboost.com/wiki/bbcode" aria-label="' . $_functions->i18n('bb_help') . ' ' . LangLoader::get_message('new.window', 'main') . '" target="_blank" rel="noopener">
					<i class="fa fa-fw bbcode-icon-help" aria-hidden="true" title="' . $_functions->i18n('bb_help') . '"></i>
				</a>
			</li>
		</ul>
	</div>

	<div class="bbcode-elements bkgd-color-op20-hover bbcode-elements-more">
		<a href="" aria-label="' . $_functions->i18n('bb_more') . '" title="' . $_functions->i18n('bb_more') . '" onclick="show_bbcode_div(\'bbcode-container-more\');return false;">
			<i class="fa fa-fw bbcode-icon-more bbcode-hover"></i>
		</a>
	</div>

</div>

<script>
<!--
set_bbcode_preference(\'bbcode-container-more\');
-->
</script>
'; ?>