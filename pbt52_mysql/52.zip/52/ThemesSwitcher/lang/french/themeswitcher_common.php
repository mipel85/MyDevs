<?php
/**
 * @copyright 	&copy; 2005-2019 PHPBoost
 * @license 	https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      Regis VIARRE <crowkait@phpboost.com>
 * @version   	PHPBoost 5.2 - last update: 2016 09 08
 * @since   	PHPBoost 3.0 - 2009 08 24
*/

####################################################
#                    French                        #
####################################################

$LANG['switch_theme'] = 'Changer le thème';
$LANG['defaut_theme'] = 'Thème par défaut';
?>
