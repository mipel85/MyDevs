<?php
/**
 * @copyright 	&copy; 2005-2019 PHPBoost
 * @license 	https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      Julien BRISWALTER <j1.seth@phpboost.com>
 * @version   	PHPBoost 5.2 - last update: 2017 03 26
 * @since   	PHPBoost 4.0 - 2014 05 09
*/

#####################################################
#                    French                         #
#####################################################

$lang['question1_label'] = 'Combien font 4 + cinq ?';
$lang['question1_answers'] = '9;neuf';
$lang['question2_label'] = 'Combien y a-t-il de voyelles dans le mot ordinateur ?';
$lang['question2_answers'] = '5;cinq';
?>
